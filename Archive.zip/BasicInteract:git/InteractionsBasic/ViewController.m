//
//  ViewController.m
//  InteractionsBasic
//
//  Created by Victor  Adu on 4/27/14.
//  Copyright (c) 2014 Victor  Adu. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@property (weak, nonatomic) IBOutlet UITextField *simpleTextField;

@property (weak, nonatomic) IBOutlet UILabel *simpleLabel;

@end

@implementation ViewController

- (IBAction)changeLabel:(id)sender {
    //
    NSString *contents = [[self simpleTextField] text];
    //               Or: self.simpleTextField.text
    NSString *message = [NSString stringWithFormat:@"Hello, %@", contents];
    [self.simpleLabel setText:message];
    
    [self.simpleTextField resignFirstResponder]; //clear keyboard when textfield not in use.
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder]; //This will close out keyboard after user hits 'Return'
    return YES;
}

// This method doesnt intefere with buttons and text and other objects on UI Screen. You can basically use this method to respond to resign keyboard upon touching any part of the screen.
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    [self.view endEditing:YES]; // Very useful when you have many Outlets and Actions on UI Screen
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
